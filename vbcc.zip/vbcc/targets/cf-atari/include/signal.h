#ifndef __SIGNAL_H
#define __SIGNAL_H 1

typedef volatile int sig_atomic_t;

void (*signal(int,void (*)(int)))(int);
int raise(int);

/* MiNT signals */
#define SIGNULL	0
#define SIGHUP	1
#define SIGINT	2
#define	SIGQUIT	3
#define SIGILL	4
#define SIGTRAP	5
#define SIGABRT	6
#define SIGPRIV	7
#define SIGFPE	8
#define SIGKILL	9
#define SIGBUS	10
#define SIGSEGV	11
#define SIGSYS	12
#define SIGPIPE	13
#define SIGALRM	14
#define SIGTERM	15
#define SIGURG	16
#define SIGSTOP	17
#define SIGTSTP	18
#define SIGCONT	19
#define SIGCHLD	20
#define SIGTTIN	21
#define SIGTTOU	22
#define SIGIO	23
#define SIGXCPU	24
#define SIGXFSZ	25
#define SIGVTALRM	26
#define SIGPROF	27
#define SIGWINCH	28
#define SIGUSR1	29
#define SIGUSR2	30

#define SIG_ERR (void (*)(int))0
#define SIG_DFL (void (*)(int))1
#define SIG_IGN (void (*)(int))2

#endif
